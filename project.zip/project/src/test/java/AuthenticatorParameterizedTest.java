import LoginRegistration.Authenticator;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

public class AuthenticatorParameterizedTest {

    private final Authenticator auth = new Authenticator();

    // === REGISTRATION TEST ===
    @ParameterizedTest(name = "Reg: {0}, {1}, {2}, {3}, {4} -> success: {5}")
    @CsvSource({
        // firstName, lastName, username, password, cellphone, expectedSuccess
        "John,Doe,a_bc,Pass@123,+27608697402,true",
        "Jane,Smith,abcde,Pass@123,+27608697402,false",   // username too long
        "Alice,Lee,a_bc,password,+27608697402,false",     // invalid password
        "Bob,King,a_bc,Pass@123,27608697402,false",       // missing + in phone
        "Sam,Ray,a_bc,Pass@123,+27608697402,false"        // duplicate username
    })
    void testRegistration(String firstName, String lastName,
                          String username, String password, String cellphone,
                          boolean expectedSuccess) {

        String result = auth.register(firstName, lastName, username, password, cellphone);

        if (expectedSuccess) {
            assertTrue(result.contains("Registration successful"), "Expected success");
        } else {
            assertTrue(result.contains("Invalid") || result.contains("exists"),
                    "Expected failure due to invalid input or duplicate");
        }
    }

    // === LOGIN TEST ===
    @ParameterizedTest(name = "Login: {0}, {1} -> success: {2}")
    @CsvSource({
        "a_bc,Pass@123,true",
        "a_bc,WrongPass,false",
        "not_user,Pass@123,false"
    })
    void testLogin(String username, String password, boolean expectedSuccess) {
        // Ensure user exists for login tests
        auth.register("Test", "User", "a_bc", "Pass@123", "+27608697402");

        String result = auth.login(username, password);

        if (expectedSuccess) {
            assertTrue(result.contains("Login successful"), "Expected successful login");
        } else {
            assertEquals("❌ Invalid credentials!", result, "Expected failed login");
        }
    }
}
