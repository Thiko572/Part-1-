/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project;

import LoginRegistration.Authenticator;
import java.util.Scanner;


public class Project {

  private static Scanner scanner = new Scanner(System.in);
    private static Authenticator auth = new Authenticator();
    
 private static void handleRegister() {
        System.out.println("\n=== REGISTRATION ===");
        System.out.println("First Name: ");
        String firstName = scanner.nextLine();

        System.out.println("Last Name: ");
        String lastName = scanner.nextLine();

        System.out.println("Username (underscore, max 5 chars): ");
        String username = scanner.nextLine();

        System.out.println("Password (>=8 chars, 1 capital, 1 number, 1 special char): ");
        String password = scanner.nextLine();

        System.out.println("Cellphone (+countrycode...): ");
        String cellphone = scanner.nextLine();

        System.out.println(auth.register(firstName, lastName, username, password, cellphone));
    

    }

    private static void handleLogin() {
        System.out.println("\n=== LOGIN ===");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.println(auth.login(username, password));
    }

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1. Register\n2. Login\n3. Exit");
            System.out.print("Choose option: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> handleRegister();
                case "2" -> handleLogin();
                case "3" -> {
                    System.out.println("Bye!"); return;
                }
                default -> System.out.println("Invalid option!");
            }
        }
    }

}
